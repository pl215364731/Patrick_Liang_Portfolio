To compile the program:
Enter "gcc --std=gnu99 -o movies main.c" OR "make" into the terminal

To run the program:
Enter "./movies <your file>" into the terminal
