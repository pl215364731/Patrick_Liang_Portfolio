To compile the program:
Enter "gcc --std=gnu99 -o movies_by_year main.c" OR "make" into the terminal

To run the program:
Enter "./movies_by_year" into the terminal
