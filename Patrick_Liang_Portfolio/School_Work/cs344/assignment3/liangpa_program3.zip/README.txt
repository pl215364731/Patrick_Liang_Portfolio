To compile the program:
Enter "gcc --std=gnu99 -o smallsh main.c" OR "make" into the terminal

To run the program:
Enter "smallsh" into the terminal
