To compile the program:
Enter "gcc --std=gnu99 -pthread -o line_processor main.c" OR "make" into the terminal

To run the program:
Enter "line_processor" into the terminal
